package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val aspectRatio: String = AspectRatio.RATIO_9_16.label,
    val coverResId: Int? = null,
    val coverUri: String? = null,
    val clipsJson: String = "[]",
    val audioJson: String = "[]",
    val textJson: String = "[]",
    val resolution: String = "1080P",
    val fps: Int = 60
)
