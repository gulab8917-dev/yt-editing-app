package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ExportSettings
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutDivider
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutSurfaceElevated
import com.example.ui.theme.CapCutTextPrimary
import com.example.ui.theme.CapCutTextSecondary

@Composable
fun ExportDialog(
    exportSettings: ExportSettings,
    isExporting: Boolean,
    exportProgress: Float,
    exportPhaseText: String,
    exportFinished: Boolean,
    durationMs: Long,
    onSettingsChange: (ExportSettings) -> Unit,
    onStartExport: () -> Unit,
    onCancelExport: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedRes by remember { mutableStateOf(exportSettings.resolution) }
    var selectedFps by remember { mutableIntStateOf(exportSettings.fps) }

    Dialog(onDismissRequest = {
        if (!isExporting) onDismiss()
    }) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CapCutSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CapCutDivider),
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (exportFinished) "Ready to Share" else if (isExporting) "Exporting Video" else "Export Settings",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = {
                            if (isExporting) onCancelExport()
                            onDismiss()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = CapCutTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (exportFinished) {
                    // Export Complete Celebration View
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = CapCutCyan,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Saved to Device Album!",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$selectedRes • ${selectedFps}fps • MP4",
                        color = CapCutTextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text("Quick Share to:", color = CapCutTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        SharePlatformChip(name = "TikTok", color = Color(0xFF00F2FE))
                        SharePlatformChip(name = "Reels", color = Color(0xFFE1306C))
                        SharePlatformChip(name = "Shorts", color = Color(0xFFFF0000))
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = CapCutCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("export_done_btn")
                    ) {
                        Text("Done", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                } else if (isExporting) {
                    // Real-time Export Progress
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(110.dp)
                    ) {
                        CircularProgressIndicator(
                            progress = { exportProgress },
                            color = CapCutCyan,
                            trackColor = CapCutDivider,
                            strokeWidth = 6.dp,
                            modifier = Modifier.size(110.dp)
                        )
                        Text(
                            text = "${(exportProgress * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = exportPhaseText,
                        color = CapCutCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Don't lock your screen or switch apps",
                        color = CapCutTextSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onCancelExport,
                        colors = ButtonDefaults.buttonColors(containerColor = CapCutSurfaceElevated),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }

                } else {
                    // Settings Selection (Resolution & Frame Rate)
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text("Resolution", color = CapCutTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("720P", "1080P", "2K/4K").forEach { res ->
                                val isSel = res == selectedRes
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) CapCutCyan else CapCutSurfaceElevated,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedRes = res
                                            onSettingsChange(exportSettings.copy(resolution = res))
                                        }
                                        .testTag("res_$res")
                                ) {
                                    Text(
                                        text = res,
                                        color = if (isSel) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 10.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Frame Rate (FPS)", color = CapCutTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(24, 30, 50, 60).forEach { fps ->
                                val isSel = fps == selectedFps
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) CapCutCyan else CapCutSurfaceElevated,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedFps = fps
                                            onSettingsChange(exportSettings.copy(fps = fps))
                                        }
                                        .testTag("fps_$fps")
                                ) {
                                    Text(
                                        text = "$fps",
                                        color = if (isSel) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Smart estimated file size
                        val estimatedMb = (durationMs / 1000f * when (selectedRes) {
                            "720P" -> 1.2f
                            "1080P" -> 2.5f
                            else -> 5.8f
                        } * (selectedFps / 30f)).coerceAtLeast(4.0f)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CapCutSurfaceElevated, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Estimated File Size", color = CapCutTextSecondary, fontSize = 12.sp)
                            Text(String.format("~%.1f MB", estimatedMb), color = CapCutCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onStartExport,
                            colors = ButtonDefaults.buttonColors(containerColor = CapCutCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("start_export_btn")
                        ) {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = "Export", tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export Now", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SharePlatformChip(name: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CapCutSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(8.dp).background(color, CircleShape))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
