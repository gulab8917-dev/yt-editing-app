package com.example.data.model

import com.example.R
import java.util.UUID

data class TemplateItem(
    val id: String,
    val title: String,
    val creator: String,
    val likes: String,
    val uses: String,
    val durationSeconds: Int,
    val clipCount: Int,
    val aspectRatio: AspectRatio,
    val coverResId: Int,
    val soundtrackTitle: String,
    val category: String,
    val tags: List<String>,
    val generateClips: () -> List<VideoClip>,
    val generateAudio: () -> AudioTrackItem,
    val generateTexts: () -> List<TextOverlayItem>
)

object TemplateLibrary {
    val templates = listOf(
        TemplateItem(
            id = "template_velocity_sync",
            title = "Ultra Fast Velocity Beat Sync",
            creator = "AlexVFX",
            likes = "2.4M",
            uses = "982K",
            durationSeconds = 12,
            clipCount = 4,
            aspectRatio = AspectRatio.RATIO_9_16,
            coverResId = R.drawable.template_velocity_1790502966219,
            soundtrackTitle = "Tokyo Drift Phonk (Beat Sync)",
            category = "Velocity",
            tags = listOf("Trending", "BeatSync", "FastCut"),
            generateClips = {
                listOf(
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Beat 1 - Drop",
                        thumbnailRes = R.drawable.template_velocity_1790502966219,
                        durationMs = 2800L,
                        trimEndMs = 2800L,
                        speed = 1.4f,
                        filter = FilterType.CYBER_NEON,
                        transition = TransitionType.ZOOM_IN
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Beat 2 - Flash",
                        thumbnailRes = R.drawable.template_aesthetic_1790502995311,
                        durationMs = 2400L,
                        trimEndMs = 2400L,
                        speed = 1.6f,
                        filter = FilterType.RETRO_VHS,
                        transition = TransitionType.GLITCH
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Beat 3 - Speed Curve",
                        thumbnailRes = R.drawable.template_cinematic_1790502980073,
                        durationMs = 3200L,
                        trimEndMs = 3200L,
                        speed = 2.0f,
                        filter = FilterType.TEAL_ORANGE,
                        transition = TransitionType.WHIP_PAN
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Beat 4 - Finale",
                        thumbnailRes = R.drawable.template_velocity_1790502966219,
                        durationMs = 3600L,
                        trimEndMs = 3600L,
                        speed = 1.2f,
                        filter = FilterType.CINEMATIC,
                        transition = TransitionType.DISSOLVE
                    )
                )
            },
            generateAudio = {
                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    title = "Tokyo Drift Phonk (Slowed + Reverb)",
                    artist = "CapCut Trending Beat",
                    durationMs = 12000L,
                    volume = 1.0f
                )
            },
            generateTexts = {
                listOf(
                    TextOverlayItem(
                        id = UUID.randomUUID().toString(),
                        text = "NEVER STOP ⚡",
                        startMs = 500L,
                        durationMs = 2500L,
                        textColorHex = "#00F0FF",
                        fontSizeSp = 28f,
                        animation = "Glitch In"
                    ),
                    TextOverlayItem(
                        id = UUID.randomUUID().toString(),
                        text = "VELOCITY DROP 🚀",
                        startMs = 3200L,
                        durationMs = 3000L,
                        textColorHex = "#FF007A",
                        fontSizeSp = 30f,
                        animation = "Shake"
                    )
                )
            }
        ),
        TemplateItem(
            id = "template_cinematic_vlog",
            title = "35mm Cinematic Travel Film",
            creator = "StudioCinemas",
            likes = "1.8M",
            uses = "650K",
            durationSeconds = 14,
            clipCount = 3,
            aspectRatio = AspectRatio.RATIO_9_16,
            coverResId = R.drawable.template_cinematic_1790502980073,
            soundtrackTitle = "Horizons Cinematic Build",
            category = "Cinematic",
            tags = listOf("Cinematic", "35mm", "GoldenHour"),
            generateClips = {
                listOf(
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Scenic Route",
                        thumbnailRes = R.drawable.template_cinematic_1790502980073,
                        durationMs = 5000L,
                        trimEndMs = 5000L,
                        speed = 0.9f,
                        filter = FilterType.SUNSET_WARM,
                        transition = TransitionType.DISSOLVE
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Golden Horizon",
                        thumbnailRes = R.drawable.template_aesthetic_1790502995311,
                        durationMs = 4500L,
                        trimEndMs = 4500L,
                        speed = 1.0f,
                        filter = FilterType.CINEMATIC,
                        transition = TransitionType.FADE_BLACK
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Coastal Drive",
                        thumbnailRes = R.drawable.template_velocity_1790502966219,
                        durationMs = 4500L,
                        trimEndMs = 4500L,
                        speed = 0.8f,
                        filter = FilterType.TEAL_ORANGE,
                        transition = TransitionType.NONE
                    )
                )
            },
            generateAudio = {
                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    title = "Horizons Cinematic Build",
                    artist = "Film Score Pro",
                    durationMs = 14000L,
                    volume = 0.9f
                )
            },
            generateTexts = {
                listOf(
                    TextOverlayItem(
                        id = UUID.randomUUID().toString(),
                        text = "chapter one: freedom 🌅",
                        startMs = 800L,
                        durationMs = 3800L,
                        textColorHex = "#FFFFFF",
                        fontSizeSp = 22f,
                        animation = "Fade In"
                    )
                )
            }
        ),
        TemplateItem(
            id = "template_aesthetic_90s",
            title = "Aesthetic Film Cam 90s Grain",
            creator = "VibeArchive",
            likes = "940K",
            uses = "430K",
            durationSeconds = 10,
            clipCount = 3,
            aspectRatio = AspectRatio.RATIO_9_16,
            coverResId = R.drawable.template_aesthetic_1790502995311,
            soundtrackTitle = "Midnight Coffee Lo-Fi",
            category = "Aesthetic",
            tags = listOf("Retro", "LoFi", "Grain"),
            generateClips = {
                listOf(
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Film Reel A",
                        thumbnailRes = R.drawable.template_aesthetic_1790502995311,
                        durationMs = 3500L,
                        trimEndMs = 3500L,
                        speed = 1.0f,
                        filter = FilterType.RETRO_VHS,
                        transition = TransitionType.GLITCH
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Film Reel B",
                        thumbnailRes = R.drawable.template_cinematic_1790502980073,
                        durationMs = 3500L,
                        trimEndMs = 3500L,
                        speed = 1.0f,
                        filter = FilterType.RETRO_VHS,
                        transition = TransitionType.DISSOLVE
                    ),
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        title = "Film Reel C",
                        thumbnailRes = R.drawable.template_velocity_1790502966219,
                        durationMs = 3000L,
                        trimEndMs = 3000L,
                        speed = 1.0f,
                        filter = FilterType.MONO_BW,
                        transition = TransitionType.NONE
                    )
                )
            },
            generateAudio = {
                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    title = "Midnight Coffee Lo-Fi",
                    artist = "Retro Beats",
                    durationMs = 10000L,
                    volume = 0.8f
                )
            },
            generateTexts = {
                listOf(
                    TextOverlayItem(
                        id = UUID.randomUUID().toString(),
                        text = "1997 vintage tape",
                        startMs = 500L,
                        durationMs = 3000L,
                        textColorHex = "#FDE047",
                        fontSizeSp = 24f,
                        animation = "Typewriter"
                    )
                )
            }
        )
    )
}
