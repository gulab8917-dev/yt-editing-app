package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MovieFilter
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutTextPrimary
import com.example.ui.theme.CapCutTextSecondary

enum class BottomMenuMode {
    ROOT,
    CLIP_EDIT
}

@Composable
fun CapCutBottomBar(
    modifier: Modifier = Modifier,
    onSplitClick: () -> Unit,
    onSpeedClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onDuplicateClick: () -> Unit,
    onFilterClick: () -> Unit,
    onAdjustClick: () -> Unit,
    onAudioClick: () -> Unit,
    onTextClick: () -> Unit,
    onRatioClick: () -> Unit,
    onEffectsClick: () -> Unit
) {
    var menuMode by remember { mutableStateOf(BottomMenuMode.ROOT) }
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(CapCutSurface)
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .horizontalScroll(scrollState)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (menuMode == BottomMenuMode.ROOT) {
                // Root Menu items
                ToolbarActionItem(
                    icon = Icons.Default.CallSplit,
                    label = "Edit",
                    tag = "tool_edit",
                    onClick = { menuMode = BottomMenuMode.CLIP_EDIT }
                )
                ToolbarActionItem(
                    icon = Icons.Default.MusicNote,
                    label = "Audio",
                    tag = "tool_audio",
                    onClick = onAudioClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.TextFields,
                    label = "Text",
                    tag = "tool_text",
                    onClick = onTextClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.MovieFilter,
                    label = "Filters",
                    tag = "tool_filters",
                    onClick = onFilterClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.Tune,
                    label = "Adjust",
                    tag = "tool_adjust",
                    onClick = onAdjustClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.AutoFixHigh,
                    label = "Effects",
                    tag = "tool_effects",
                    onClick = onEffectsClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.Crop,
                    label = "Ratio",
                    tag = "tool_ratio",
                    onClick = onRatioClick
                )
            } else {
                // Secondary Clip Edit Menu items
                ToolbarActionItem(
                    icon = Icons.AutoMirrored.Filled.ArrowBack,
                    label = "Back",
                    tag = "tool_back",
                    tint = CapCutCyan,
                    onClick = { menuMode = BottomMenuMode.ROOT }
                )
                ToolbarActionItem(
                    icon = Icons.Default.CallSplit,
                    label = "Split",
                    tag = "tool_split_action",
                    onClick = onSplitClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.Speed,
                    label = "Speed",
                    tag = "tool_speed_action",
                    onClick = onSpeedClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.ContentCopy,
                    label = "Duplicate",
                    tag = "tool_duplicate_action",
                    onClick = onDuplicateClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.Delete,
                    label = "Delete",
                    tag = "tool_delete_action",
                    tint = Color(0xFFFF5252),
                    onClick = onDeleteClick
                )
                ToolbarActionItem(
                    icon = Icons.Default.Tune,
                    label = "Adjust",
                    tag = "tool_clip_adjust",
                    onClick = onAdjustClick
                )
            }
        }
    }
}

@Composable
private fun ToolbarActionItem(
    icon: ImageVector,
    label: String,
    tag: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(58.dp)
            .clickable { onClick() }
            .padding(vertical = 4.dp)
            .testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = CapCutTextSecondary,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}
