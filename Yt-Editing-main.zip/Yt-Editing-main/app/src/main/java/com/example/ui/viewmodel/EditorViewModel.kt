package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.ProjectJsonConverter
import com.example.data.model.AspectRatio
import com.example.data.model.AudioTrackItem
import com.example.data.model.ExportSettings
import com.example.data.model.FilterType
import com.example.data.model.SampleMedia
import com.example.data.model.TextOverlayItem
import com.example.data.model.TransitionType
import com.example.data.model.VideoClip
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class ToolModalType {
    NONE,
    SPEED,
    TRANSITION,
    FILTER,
    ADJUST,
    TEXT_EDITOR,
    AUDIO_PICKER,
    ASPECT_RATIO,
    EXPORT
}

data class TimelineSnapshot(
    val clips: List<VideoClip>,
    val audioTracks: List<AudioTrackItem>,
    val textOverlays: List<TextOverlayItem>,
    val aspectRatio: AspectRatio
)

data class EditorUiState(
    val projectId: String = "",
    val projectTitle: String = "Untitled",
    val clips: List<VideoClip> = emptyList(),
    val selectedClipId: String? = null,
    val audioTracks: List<AudioTrackItem> = emptyList(),
    val textOverlays: List<TextOverlayItem> = emptyList(),
    val selectedTextId: String? = null,
    val selectedTransitionIndex: Int? = null,
    val aspectRatio: AspectRatio = AspectRatio.RATIO_9_16,
    val currentPlayheadMs: Long = 0L,
    val isPlaying: Boolean = false,
    val activeModal: ToolModalType = ToolModalType.NONE,
    val exportSettings: ExportSettings = ExportSettings(),
    val isExporting: Boolean = false,
    val exportProgress: Float = 0f,
    val exportPhaseText: String = "",
    val exportFinished: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isFullscreenPreview: Boolean = false
) {
    val totalDurationMs: Long
        get() = clips.sumOf { it.effectiveDurationMs }.coerceAtLeast(1000L)

    val selectedClip: VideoClip?
        get() = clips.find { it.id == selectedClipId } ?: clips.firstOrNull()

    val activeClipAtPlayhead: VideoClip?
        get() {
            var accMs = 0L
            for (clip in clips) {
                val clipDur = clip.effectiveDurationMs
                if (currentPlayheadMs >= accMs && currentPlayheadMs < accMs + clipDur) {
                    return clip
                }
                accMs += clipDur
            }
            return clips.lastOrNull()
        }

    val activeTextOverlays: List<TextOverlayItem>
        get() = textOverlays.filter {
            currentPlayheadMs >= it.startMs && currentPlayheadMs <= (it.startMs + it.durationMs)
        }
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository =
        ProjectRepository(AppDatabase.getDatabase(application).projectDao())

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private val undoStack = mutableListOf<TimelineSnapshot>()
    private val redoStack = mutableListOf<TimelineSnapshot>()

    private var playbackJob: Job? = null
    private var exportJob: Job? = null

    fun loadProject(id: String) {
        viewModelScope.launch {
            val project = repository.getProject(id)
            if (project != null) {
                val clips = ProjectJsonConverter.clipsFromJson(project.clipsJson)
                val audio = ProjectJsonConverter.audioFromJson(project.audioJson)
                val texts = ProjectJsonConverter.textFromJson(project.textJson)
                val ratio = AspectRatio.fromLabel(project.aspectRatio)

                _uiState.update {
                    it.copy(
                        projectId = project.id,
                        projectTitle = project.title,
                        clips = if (clips.isNotEmpty()) clips else SampleMedia.createDefaultProjectClips(),
                        selectedClipId = clips.firstOrNull()?.id,
                        audioTracks = audio,
                        textOverlays = texts,
                        aspectRatio = ratio,
                        currentPlayheadMs = 0L,
                        isPlaying = false,
                        exportSettings = ExportSettings(
                            resolution = project.resolution,
                            fps = project.fps
                        )
                    )
                }
                undoStack.clear()
                redoStack.clear()
                updateUndoRedoAvailability()
            }
        }
    }

    private fun pushUndoSnapshot() {
        val current = TimelineSnapshot(
            clips = _uiState.value.clips,
            audioTracks = _uiState.value.audioTracks,
            textOverlays = _uiState.value.textOverlays,
            aspectRatio = _uiState.value.aspectRatio
        )
        undoStack.add(current)
        if (undoStack.size > 20) undoStack.removeAt(0)
        redoStack.clear()
        updateUndoRedoAvailability()
    }

    private fun updateUndoRedoAvailability() {
        _uiState.update {
            it.copy(
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty()
            )
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val current = TimelineSnapshot(
            clips = _uiState.value.clips,
            audioTracks = _uiState.value.audioTracks,
            textOverlays = _uiState.value.textOverlays,
            aspectRatio = _uiState.value.aspectRatio
        )
        redoStack.add(current)

        val previous = undoStack.removeAt(undoStack.lastIndex)
        _uiState.update {
            it.copy(
                clips = previous.clips,
                audioTracks = previous.audioTracks,
                textOverlays = previous.textOverlays,
                aspectRatio = previous.aspectRatio,
                selectedClipId = previous.clips.firstOrNull()?.id
            )
        }
        updateUndoRedoAvailability()
        saveProjectToDb()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val current = TimelineSnapshot(
            clips = _uiState.value.clips,
            audioTracks = _uiState.value.audioTracks,
            textOverlays = _uiState.value.textOverlays,
            aspectRatio = _uiState.value.aspectRatio
        )
        undoStack.add(current)

        val next = redoStack.removeAt(redoStack.lastIndex)
        _uiState.update {
            it.copy(
                clips = next.clips,
                audioTracks = next.audioTracks,
                textOverlays = next.textOverlays,
                aspectRatio = next.aspectRatio,
                selectedClipId = next.clips.firstOrNull()?.id
            )
        }
        updateUndoRedoAvailability()
        saveProjectToDb()
    }

    // Playback control
    fun togglePlayPause() {
        if (_uiState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        playbackJob?.cancel()
        _uiState.update { it.copy(isPlaying = true) }
        playbackJob = viewModelScope.launch {
            while (_uiState.value.isPlaying) {
                delay(33L) // ~30 fps tick
                val total = _uiState.value.totalDurationMs
                val next = _uiState.value.currentPlayheadMs + 33L
                if (next >= total) {
                    _uiState.update { it.copy(currentPlayheadMs = 0L) }
                } else {
                    _uiState.update { it.copy(currentPlayheadMs = next) }
                }
            }
        }
    }

    fun pause() {
        playbackJob?.cancel()
        _uiState.update { it.copy(isPlaying = false) }
    }

    fun seekTo(positionMs: Long) {
        val total = _uiState.value.totalDurationMs
        val clamped = positionMs.coerceIn(0L, total)
        _uiState.update { it.copy(currentPlayheadMs = clamped) }
    }

    fun selectClip(id: String) {
        _uiState.update { it.copy(selectedClipId = id) }
    }

    // Split clip at playhead
    fun splitClipAtPlayhead() {
        val state = _uiState.value
        val playhead = state.currentPlayheadMs
        var accMs = 0L
        val currentClips = state.clips
        val newClips = mutableListOf<VideoClip>()
        var didSplit = false

        for (clip in currentClips) {
            val clipDur = clip.effectiveDurationMs
            val clipStart = accMs
            val clipEnd = accMs + clipDur

            if (!didSplit && playhead > clipStart + 300L && playhead < clipEnd - 300L) {
                pushUndoSnapshot()
                val offsetInside = ((playhead - clipStart) * clip.speed).toLong()
                val part1End = clip.trimStartMs + offsetInside

                val clipPart1 = clip.copy(
                    id = UUID.randomUUID().toString(),
                    title = "${clip.title} (Part 1)",
                    trimEndMs = part1End
                )
                val clipPart2 = clip.copy(
                    id = UUID.randomUUID().toString(),
                    title = "${clip.title} (Part 2)",
                    trimStartMs = part1End
                )
                newClips.add(clipPart1)
                newClips.add(clipPart2)
                didSplit = true
            } else {
                newClips.add(clip)
            }
            accMs += clipDur
        }

        if (didSplit) {
            _uiState.update { it.copy(clips = newClips) }
            saveProjectToDb()
        }
    }

    // Delete selected clip
    fun deleteSelectedClip() {
        val state = _uiState.value
        if (state.clips.size <= 1) return // Keep at least one clip
        val targetId = state.selectedClipId ?: return
        pushUndoSnapshot()
        val newClips = state.clips.filter { it.id != targetId }
        _uiState.update {
            it.copy(
                clips = newClips,
                selectedClipId = newClips.firstOrNull()?.id
            )
        }
        saveProjectToDb()
    }

    // Duplicate selected clip
    fun duplicateSelectedClip() {
        val state = _uiState.value
        val clip = state.selectedClip ?: return
        pushUndoSnapshot()
        val duplicate = clip.copy(
            id = UUID.randomUUID().toString(),
            title = "${clip.title} (Copy)"
        )
        val idx = state.clips.indexOfFirst { it.id == clip.id }
        val newClips = state.clips.toMutableList()
        if (idx != -1) {
            newClips.add(idx + 1, duplicate)
        } else {
            newClips.add(duplicate)
        }
        _uiState.update {
            it.copy(
                clips = newClips,
                selectedClipId = duplicate.id
            )
        }
        saveProjectToDb()
    }

    // Add clip from preset or photo picker
    fun addClip(clip: VideoClip) {
        pushUndoSnapshot()
        val newClips = _uiState.value.clips + clip
        _uiState.update {
            it.copy(
                clips = newClips,
                selectedClipId = clip.id
            )
        }
        saveProjectToDb()
    }

    // Speed adjustment
    fun setClipSpeed(clipId: String, speed: Float) {
        val clamped = speed.coerceIn(0.1f, 10.0f)
        val newClips = _uiState.value.clips.map {
            if (it.id == clipId) it.copy(speed = clamped) else it
        }
        _uiState.update { it.copy(clips = newClips) }
    }

    fun confirmSpeedChange() {
        pushUndoSnapshot()
        saveProjectToDb()
        closeModal()
    }

    // Filter selection
    fun setFilter(clipId: String, filter: FilterType) {
        pushUndoSnapshot()
        val newClips = _uiState.value.clips.map {
            if (it.id == clipId) it.copy(filter = filter) else it
        }
        _uiState.update { it.copy(clips = newClips) }
        saveProjectToDb()
    }

    fun applyFilterToAllClips(filter: FilterType) {
        pushUndoSnapshot()
        val newClips = _uiState.value.clips.map {
            it.copy(filter = filter)
        }
        _uiState.update { it.copy(clips = newClips) }
        saveProjectToDb()
    }

    // Color Adjustments
    fun updateAdjustments(
        clipId: String,
        brightness: Float,
        contrast: Float,
        saturation: Float,
        vignette: Float
    ) {
        val newClips = _uiState.value.clips.map {
            if (it.id == clipId) {
                it.copy(
                    brightness = brightness,
                    contrast = contrast,
                    saturation = saturation,
                    vignette = vignette
                )
            } else it
        }
        _uiState.update { it.copy(clips = newClips) }
    }

    fun confirmAdjustments() {
        pushUndoSnapshot()
        saveProjectToDb()
        closeModal()
    }

    // Transitions
    fun selectTransitionSlot(index: Int) {
        _uiState.update {
            it.copy(
                selectedTransitionIndex = index,
                activeModal = ToolModalType.TRANSITION
            )
        }
    }

    fun setTransition(transitionType: TransitionType, durationMs: Long = 600L) {
        val idx = _uiState.value.selectedTransitionIndex ?: return
        if (idx in _uiState.value.clips.indices) {
            pushUndoSnapshot()
            val newClips = _uiState.value.clips.toMutableList()
            newClips[idx] = newClips[idx].copy(
                transition = transitionType,
                transitionDurationMs = durationMs
            )
            _uiState.update {
                it.copy(clips = newClips)
            }
            saveProjectToDb()
        }
        closeModal()
    }

    // Aspect ratio
    fun setAspectRatio(ratio: AspectRatio) {
        pushUndoSnapshot()
        _uiState.update { it.copy(aspectRatio = ratio) }
        saveProjectToDb()
        closeModal()
    }

    // Audio & Sound FX
    fun addAudioTrack(audio: AudioTrackItem) {
        pushUndoSnapshot()
        val item = audio.copy(
            id = UUID.randomUUID().toString(),
            startMs = _uiState.value.currentPlayheadMs
        )
        val newAudio = _uiState.value.audioTracks + item
        _uiState.update { it.copy(audioTracks = newAudio) }
        saveProjectToDb()
        closeModal()
    }

    fun deleteAudioTrack(id: String) {
        pushUndoSnapshot()
        val newAudio = _uiState.value.audioTracks.filter { it.id != id }
        _uiState.update { it.copy(audioTracks = newAudio) }
        saveProjectToDb()
    }

    fun toggleClipMute(clipId: String) {
        pushUndoSnapshot()
        val newClips = _uiState.value.clips.map {
            if (it.id == clipId) it.copy(isMuted = !it.isMuted) else it
        }
        _uiState.update { it.copy(clips = newClips) }
        saveProjectToDb()
    }

    // Text Overlays
    fun addOrUpdateText(
        id: String?,
        text: String,
        colorHex: String,
        bgHex: String,
        fontSizeSp: Float,
        animation: String
    ) {
        pushUndoSnapshot()
        val texts = _uiState.value.textOverlays.toMutableList()
        if (id != null) {
            val idx = texts.indexOfFirst { it.id == id }
            if (idx != -1) {
                texts[idx] = texts[idx].copy(
                    text = text,
                    textColorHex = colorHex,
                    backgroundColorHex = bgHex,
                    fontSizeSp = fontSizeSp,
                    animation = animation
                )
            }
        } else {
            val newText = TextOverlayItem(
                id = UUID.randomUUID().toString(),
                text = text,
                startMs = _uiState.value.currentPlayheadMs,
                durationMs = 3000L,
                textColorHex = colorHex,
                backgroundColorHex = bgHex,
                fontSizeSp = fontSizeSp,
                animation = animation
            )
            texts.add(newText)
        }
        _uiState.update {
            it.copy(textOverlays = texts, selectedTextId = null)
        }
        saveProjectToDb()
        closeModal()
    }

    fun deleteTextOverlay(id: String) {
        pushUndoSnapshot()
        val newTexts = _uiState.value.textOverlays.filter { it.id != id }
        _uiState.update { it.copy(textOverlays = newTexts) }
        saveProjectToDb()
    }

    // Modals
    fun openModal(modal: ToolModalType) {
        pause()
        _uiState.update { it.copy(activeModal = modal) }
    }

    fun closeModal() {
        _uiState.update {
            it.copy(
                activeModal = ToolModalType.NONE,
                selectedTransitionIndex = null
            )
        }
    }

    fun toggleFullscreenPreview() {
        _uiState.update { it.copy(isFullscreenPreview = !it.isFullscreenPreview) }
    }

    // Export Flow
    fun updateExportSettings(settings: ExportSettings) {
        _uiState.update { it.copy(exportSettings = settings) }
    }

    fun startExport() {
        pause()
        exportJob?.cancel()
        _uiState.update {
            it.copy(
                isExporting = true,
                exportProgress = 0f,
                exportPhaseText = "Analyzing timeline clips...",
                exportFinished = false
            )
        }

        exportJob = viewModelScope.launch {
            val phases = listOf(
                Pair("Encoding video frames (1080P 60FPS)...", 0.35f),
                Pair("Applying color grading & transitions...", 0.65f),
                Pair("Synthesizing multi-track audio waveform...", 0.88f),
                Pair("Finalizing MP4 container...", 1.0f)
            )

            var currentProg = 0f
            for ((phaseText, targetProg) in phases) {
                _uiState.update { it.copy(exportPhaseText = phaseText) }
                val steps = 15
                val increment = (targetProg - currentProg) / steps
                for (s in 0 until steps) {
                    delay(70L)
                    currentProg += increment
                    _uiState.update { it.copy(exportProgress = currentProg.coerceIn(0f, 1f)) }
                }
            }

            _uiState.update {
                it.copy(
                    isExporting = false,
                    exportProgress = 1.0f,
                    exportFinished = true,
                    exportPhaseText = "Export Complete! Ready to Share"
                )
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        _uiState.update {
            it.copy(
                isExporting = false,
                exportProgress = 0f,
                exportPhaseText = "",
                exportFinished = false
            )
        }
    }

    private fun saveProjectToDb() {
        val state = _uiState.value
        if (state.projectId.isBlank()) return
        viewModelScope.launch {
            repository.saveProject(
                id = state.projectId,
                title = state.projectTitle,
                durationMs = state.totalDurationMs,
                aspectRatio = state.aspectRatio.label,
                coverResId = state.clips.firstOrNull()?.thumbnailRes,
                coverUri = state.clips.firstOrNull()?.sourceUri,
                clips = state.clips,
                audioTracks = state.audioTracks,
                textOverlays = state.textOverlays,
                resolution = state.exportSettings.resolution,
                fps = state.exportSettings.fps
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        exportJob?.cancel()
    }
}
