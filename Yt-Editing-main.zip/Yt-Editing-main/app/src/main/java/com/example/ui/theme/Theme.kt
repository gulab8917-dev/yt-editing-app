package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CapCutColorScheme = darkColorScheme(
  primary = CapCutCyan,
  onPrimary = Color.Black,
  primaryContainer = CapCutSurfaceElevated,
  onPrimaryContainer = CapCutCyanLight,
  secondary = CapCutCyanLight,
  onSecondary = Color.Black,
  secondaryContainer = CapCutSurfaceVariant,
  onSecondaryContainer = Color.White,
  tertiary = TrackEffectColor,
  onTertiary = Color.White,
  background = CapCutBackground,
  onBackground = CapCutTextPrimary,
  surface = CapCutSurface,
  onSurface = CapCutTextPrimary,
  surfaceVariant = CapCutSurfaceVariant,
  onSurfaceVariant = CapCutTextSecondary,
  outline = CapCutDivider,
  outlineVariant = CapCutDivider.copy(alpha = 0.5f)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // CapCut is iconic dark by default
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = CapCutColorScheme,
    typography = Typography,
    content = content
  )
}

