package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.AspectRatio
import com.example.data.model.FilterType
import com.example.data.model.TextOverlayItem
import com.example.data.model.TransitionType
import com.example.data.model.VideoClip
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutSurface

@Composable
fun VideoPlayerCanvas(
    modifier: Modifier = Modifier,
    clip: VideoClip?,
    aspectRatio: AspectRatio,
    currentPlayheadMs: Long,
    totalDurationMs: Long,
    isPlaying: Boolean,
    activeTexts: List<TextOverlayItem>,
    isFullscreen: Boolean,
    onTogglePlayPause: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onAspectRatioClick: () -> Unit
) {
    // Generate ColorMatrix based on clip's FilterType & Adjustments
    val colorMatrix = remember(clip?.filter, clip?.brightness, clip?.contrast, clip?.saturation) {
        buildColorMatrix(
            filter = clip?.filter ?: FilterType.NORMAL,
            brightness = clip?.brightness ?: 0f,
            contrast = clip?.contrast ?: 0f,
            saturation = clip?.saturation ?: 0f
        )
    }

    // Scanline & grain animation for Retro filter
    val vhsGlitchOffset = remember { Animatable(0f) }
    LaunchedEffect(clip?.filter) {
        if (clip?.filter == FilterType.RETRO_VHS || clip?.filter == FilterType.CYBER_NEON) {
            vhsGlitchOffset.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            val containerWidth = maxWidth
            val containerHeight = maxHeight

            // Determine dimensions maintaining the aspect ratio
            val targetRatio = aspectRatio.ratioWidth / aspectRatio.ratioHeight

            Box(
                modifier = Modifier
                    .aspectRatio(targetRatio, matchHeightConstraintsFirst = targetRatio < 1f)
                    .clip(RoundedCornerShape(if (isFullscreen) 0.dp else 8.dp))
                    .background(Color(0xFF111317))
                    .border(
                        width = 1.dp,
                        color = Color(0xFF242834),
                        shape = RoundedCornerShape(if (isFullscreen) 0.dp else 8.dp)
                    )
                    .clickable { onTogglePlayPause() },
                contentAlignment = Alignment.Center
            ) {
                // Video Clip Viewport
                if (clip != null) {
                    val clipColor = parseHexColor(clip.dominantColorHex, Color(0xFF1E293B))

                    if (clip.thumbnailRes != null && clip.thumbnailRes > 0) {
                        Image(
                            painter = painterResource(id = clip.thumbnailRes),
                            contentDescription = clip.title,
                            contentScale = ContentScale.Crop,
                            colorFilter = ColorFilter.colorMatrix(colorMatrix),
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    rotationZ = clip.rotationAngle
                                }
                        )
                    } else if (clip.sourceUri.isNotBlank()) {
                        AsyncImage(
                            model = clip.sourceUri,
                            contentDescription = clip.title,
                            contentScale = ContentScale.Crop,
                            colorFilter = ColorFilter.colorMatrix(colorMatrix),
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    rotationZ = clip.rotationAngle
                                }
                        )
                    } else {
                        // Dynamic stylized generative frame
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            clipColor.copy(alpha = 0.9f),
                                            Color(0xFF0F172A),
                                            clipColor.copy(alpha = 0.7f)
                                        )
                                    )
                                )
                        )
                    }

                    // Vignette Overlay if adjusted
                    if (clip.vignette > 0f) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color.Black.copy(alpha = (clip.vignette / 100f).coerceIn(0f, 0.85f))
                                        )
                                    )
                                )
                        )
                    }

                    // Film Dust / VHS scanlines effect if retro
                    if (clip.filter == FilterType.RETRO_VHS) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color(0x33FFB703),
                                            Color.Transparent
                                        ),
                                        startY = vhsGlitchOffset.value * 200f
                                    )
                                )
                        )
                    }
                } else {
                    // Empty canvas state
                    Text(
                        text = "Add clips to preview",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }

                // Render Active Text Overlays (Captions & Stickers)
                activeTexts.forEach { textItem ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        val textColor = parseHexColor(textItem.textColorHex, Color.White)
                        val bgColor = parseHexColor(textItem.backgroundColorHex, Color(0x99000000))

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = bgColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = textItem.text,
                                color = textColor,
                                fontSize = (textItem.fontSizeSp * if (isFullscreen) 1.2f else 0.85f).sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Play / Pause central splash indicator on pause
                AnimatedVisibility(
                    visible = !isPlaying,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                            .border(1.5.dp, CapCutCyan.copy(alpha = 0.8f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }

        // Top-left aspect ratio indicator pill
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.Black.copy(alpha = 0.65f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .clickable { onAspectRatioClick() }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CropFree,
                    contentDescription = "Aspect Ratio",
                    tint = CapCutCyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = aspectRatio.label,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Top-right Fullscreen toggle button
        IconButton(
            onClick = onToggleFullscreen,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .testTag("fullscreen_button")
        ) {
            Icon(
                imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                contentDescription = "Fullscreen",
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(20.dp)
            )
        }

        // Bottom Timecode Badge
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.Black.copy(alpha = 0.65f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(8.dp)
        ) {
            val currentSec = currentPlayheadMs / 1000f
            val totalSec = totalDurationMs / 1000f
            Text(
                text = String.format("%02d:%04.1f / %02d:%04.1f",
                    (currentSec / 60).toInt(), currentSec % 60,
                    (totalSec / 60).toInt(), totalSec % 60
                ),
                color = Color.White,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }
    }
}

private fun buildColorMatrix(
    filter: FilterType,
    brightness: Float,
    contrast: Float,
    saturation: Float
): ColorMatrix {
    val matrix = ColorMatrix()

    // Base filter presets
    when (filter) {
        FilterType.MONO_BW -> {
            matrix.setToSaturation(0f)
        }
        FilterType.CYBER_NEON -> {
            matrix.setToSaturation(1.6f)
            // Boost blue/magenta
            val vals = floatArrayOf(
                1.2f, 0f, 0.2f, 0f, 10f,
                0f, 0.9f, 0f, 0f, -5f,
                0.2f, 0f, 1.4f, 0f, 25f,
                0f, 0f, 0f, 1f, 0f
            )
            val neonM = ColorMatrix(vals)
            matrix.timesAssign(neonM)
        }
        FilterType.TEAL_ORANGE -> {
            val vals = floatArrayOf(
                1.2f, 0.0f, 0.0f, 0f, 15f,
                0.0f, 1.0f, 0.1f, 0f, 5f,
                -0.1f, 0.1f, 1.3f, 0f, 20f,
                0f, 0f, 0f, 1f, 0f
            )
            matrix.timesAssign(ColorMatrix(vals))
        }
        FilterType.RETRO_VHS -> {
            matrix.setToSaturation(0.85f)
            val vals = floatArrayOf(
                1.1f, 0f, 0f, 0f, 20f,
                0f, 1.05f, 0f, 0f, 10f,
                0f, 0f, 0.9f, 0f, -10f,
                0f, 0f, 0f, 1f, 0f
            )
            matrix.timesAssign(ColorMatrix(vals))
        }
        FilterType.SUNSET_WARM -> {
            val vals = floatArrayOf(
                1.25f, 0f, 0f, 0f, 25f,
                0f, 1.1f, 0f, 0f, 12f,
                0f, 0f, 0.85f, 0f, -15f,
                0f, 0f, 0f, 1f, 0f
            )
            matrix.timesAssign(ColorMatrix(vals))
        }
        FilterType.EMERALD_COOL -> {
            val vals = floatArrayOf(
                0.85f, 0f, 0f, 0f, -10f,
                0f, 1.25f, 0f, 0f, 20f,
                0f, 0.1f, 1.15f, 0f, 15f,
                0f, 0f, 0f, 1f, 0f
            )
            matrix.timesAssign(ColorMatrix(vals))
        }
        FilterType.CINEMATIC -> {
            matrix.setToSaturation(1.1f)
            val vals = floatArrayOf(
                1.1f, 0f, 0f, 0f, -5f,
                0f, 1.05f, 0f, 0f, -5f,
                0f, 0f, 1.1f, 0f, -5f,
                0f, 0f, 0f, 1f, 0f
            )
            matrix.timesAssign(ColorMatrix(vals))
        }
        FilterType.NORMAL -> {
            // Default 1:1 identity
        }
    }

    // Additional manual adjustments
    if (saturation != 0f) {
        val satMatrix = ColorMatrix()
        satMatrix.setToSaturation((1f + (saturation / 100f)).coerceAtLeast(0f))
        matrix.timesAssign(satMatrix)
    }

    if (brightness != 0f) {
        val bOffset = brightness * 1.5f
        val bMatrix = ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, bOffset,
            0f, 1f, 0f, 0f, bOffset,
            0f, 0f, 1f, 0f, bOffset,
            0f, 0f, 0f, 1f, 0f
        ))
        matrix.timesAssign(bMatrix)
    }

    return matrix
}

private fun parseHexColor(hex: String, fallback: Color): Color {
    return try {
        val clean = hex.removePrefix("#")
        when (clean.length) {
            6 -> Color(android.graphics.Color.parseColor("#$clean"))
            8 -> Color(android.graphics.Color.parseColor("#$clean"))
            else -> fallback
        }
    } catch (e: Exception) {
        fallback
    }
}
