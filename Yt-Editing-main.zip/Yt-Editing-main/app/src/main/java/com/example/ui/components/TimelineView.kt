package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AudioTrackItem
import com.example.data.model.TextOverlayItem
import com.example.data.model.TransitionType
import com.example.data.model.VideoClip
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutDivider
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutSurfaceElevated
import com.example.ui.theme.CapCutSurfaceVariant
import com.example.ui.theme.CapCutTextMuted
import com.example.ui.theme.CapCutTextPrimary
import com.example.ui.theme.CapCutTextSecondary
import com.example.ui.theme.TrackAudioColor
import com.example.ui.theme.TrackTextColor
import kotlin.math.roundToInt

@Composable
fun TimelineView(
    modifier: Modifier = Modifier,
    clips: List<VideoClip>,
    selectedClipId: String?,
    audioTracks: List<AudioTrackItem>,
    textOverlays: List<TextOverlayItem>,
    currentPlayheadMs: Long,
    totalDurationMs: Long,
    isPlaying: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onPlayPauseClick: () -> Unit,
    onUndoClick: () -> Unit,
    onRedoClick: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSelectClip: (String) -> Unit,
    onTransitionClick: (Int) -> Unit,
    onAddClipClick: () -> Unit,
    onAddAudioClick: () -> Unit,
    onAddTextClick: () -> Unit,
    onToggleMute: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    // Timeline scaling factor: pixels per millisecond
    val pxPerMs = 0.08f // 1 second = 80dp

    // Auto-scroll timeline to follow playhead if playing
    LaunchedEffect(currentPlayheadMs, isPlaying) {
        if (isPlaying) {
            val playheadPx = (currentPlayheadMs * pxPerMs).roundToInt()
            val targetScroll = (playheadPx - 300).coerceAtLeast(0)
            if (targetScroll != scrollState.value) {
                scrollState.scrollTo(targetScroll)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF13151B))
    ) {
        // Quick Timeline Action Header (Undo, Redo, Play/Pause, Timecode, Mute)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CapCutSurface)
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onUndoClick,
                    enabled = canUndo,
                    modifier = Modifier.size(36.dp).testTag("timeline_undo")
                ) {
                    Icon(
                        imageVector = Icons.Default.Undo,
                        contentDescription = "Undo",
                        tint = if (canUndo) Color.White else CapCutTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onRedoClick,
                    enabled = canRedo,
                    modifier = Modifier.size(36.dp).testTag("timeline_redo")
                ) {
                    Icon(
                        imageVector = Icons.Default.Redo,
                        contentDescription = "Redo",
                        tint = if (canRedo) Color.White else CapCutTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Timecode
                val curSec = currentPlayheadMs / 1000f
                val totSec = totalDurationMs / 1000f
                Text(
                    text = String.format("%02d:%04.1f", (curSec / 60).toInt(), curSec % 60),
                    color = CapCutCyan,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = String.format(" / %02d:%04.1f", (totSec / 60).toInt(), totSec % 60),
                    color = CapCutTextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Quick Mute / Unmute Clip audio
                val selectedClip = clips.find { it.id == selectedClipId } ?: clips.firstOrNull()
                IconButton(
                    onClick = {
                        selectedClip?.let { onToggleMute(it.id) }
                    },
                    modifier = Modifier.size(36.dp).testTag("clip_mute_toggle")
                ) {
                    Icon(
                        imageVector = if (selectedClip?.isMuted == true) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Mute Clip",
                        tint = if (selectedClip?.isMuted == true) Color(0xFFFF5252) else CapCutTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Play / Pause button
                IconButton(
                    onClick = onPlayPauseClick,
                    modifier = Modifier
                        .size(36.dp)
                        .background(CapCutCyan.copy(alpha = 0.15f), CircleShape)
                        .testTag("timeline_play_pause")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = CapCutCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = CapCutDivider, thickness = 1.dp)

        // Multi-Track Horizontal Scrolling Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp)
                .background(Color(0xFF0F1116))
        ) {
            // Scrollable Timeline Content
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .horizontalScroll(scrollState)
                    .pointerInput(totalDurationMs) {
                        detectTapGestures { offset ->
                            val clickedMs = (offset.x / pxPerMs).toLong().coerceIn(0L, totalDurationMs)
                            onSeekTo(clickedMs)
                        }
                    }
                    .padding(start = 24.dp, end = 200.dp)
            ) {
                Column(modifier = Modifier.fillMaxHeight()) {

                    // 1. Timecode Ruler with tick marks
                    TimelineRuler(
                        totalDurationMs = totalDurationMs,
                        pxPerMs = pxPerMs,
                        modifier = Modifier
                            .height(24.dp)
                            .fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // 2. Video Track (Clips & Transitions)
                    Row(
                        modifier = Modifier.height(58.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        clips.forEachIndexed { index, clip ->
                            val isSelected = clip.id == selectedClipId
                            val clipWidthDp = ((clip.effectiveDurationMs * pxPerMs)).dp.coerceAtLeast(50.dp)

                            // Clip Segment Item
                            Box(
                                modifier = Modifier
                                    .width(clipWidthDp)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E2330))
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) Color.White else Color(0xFF333B4F),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { onSelectClip(clip.id) }
                                    .testTag("clip_item_${clip.id}")
                            ) {
                                // Thumbnail or preview color
                                if (clip.thumbnailRes != null && clip.thumbnailRes > 0) {
                                    Image(
                                        painter = painterResource(id = clip.thumbnailRes),
                                        contentDescription = clip.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize().alpha(0.65f)
                                    )
                                } else if (clip.sourceUri.isNotBlank()) {
                                    AsyncImage(
                                        model = clip.sourceUri,
                                        contentDescription = clip.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize().alpha(0.65f)
                                    )
                                }

                                // Dark gradient scrim for legibility
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color.Black.copy(alpha = 0.2f), Color.Black.copy(alpha = 0.7f))
                                            )
                                        )
                                )

                                // Clip Title & Duration text
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(4.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = clip.title,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = String.format("%.1fs", clip.effectiveDurationMs / 1000f),
                                            color = CapCutCyan,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (clip.speed != 1.0f) {
                                            Text(
                                                text = "${clip.speed}x",
                                                color = Color(0xFFFDE047),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                // Selection Trim Handles if selected
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterStart)
                                            .width(5.dp)
                                            .fillMaxHeight()
                                            .background(Color.White)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterEnd)
                                            .width(5.dp)
                                            .fillMaxHeight()
                                            .background(Color.White)
                                    )
                                }
                            }

                            // Transition Button between clips
                            if (index < clips.lastIndex) {
                                val hasTransition = clip.transition != TransitionType.NONE
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 4.dp)
                                        .size(24.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (hasTransition) CapCutCyan else Color(0xFF2A2E3D))
                                        .clickable { onTransitionClick(index) }
                                        .testTag("transition_btn_$index"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Transform,
                                        contentDescription = "Transition",
                                        tint = if (hasTransition) Color.Black else Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        // Add Media (+) Button at end of video track
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CapCutSurfaceElevated)
                                .border(1.dp, CapCutDivider, RoundedCornerShape(8.dp))
                                .clickable { onAddClipClick() }
                                .testTag("add_clip_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Clip",
                                tint = CapCutCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // 3. Audio Track (Waveform & SFX)
                    Row(
                        modifier = Modifier.height(34.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (audioTracks.isNotEmpty()) {
                            audioTracks.forEach { audio ->
                                val audioWidthDp = ((audio.durationMs * pxPerMs)).dp.coerceAtLeast(60.dp)
                                val offsetStartDp = ((audio.startMs * pxPerMs)).dp

                                Box(
                                    modifier = Modifier
                                        .padding(start = offsetStartDp)
                                        .width(audioWidthDp)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(TrackAudioColor.copy(alpha = 0.85f))
                                        .padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MusicNote,
                                            contentDescription = "Audio",
                                            tint = Color.White,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = audio.title,
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        } else {
                            // Empty audio placeholder with Add Audio pill
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1E202A),
                                modifier = Modifier
                                    .clickable { onAddAudioClick() }
                                    .testTag("add_audio_pill")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = "Add Audio",
                                        tint = TrackAudioColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "+ Add Audio / Music",
                                        color = CapCutTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // 4. Text & Subtitle Track
                    Row(
                        modifier = Modifier.height(30.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (textOverlays.isNotEmpty()) {
                            textOverlays.forEach { textItem ->
                                val textWidthDp = ((textItem.durationMs * pxPerMs)).dp.coerceAtLeast(50.dp)
                                val offsetStartDp = ((textItem.startMs * pxPerMs)).dp

                                Box(
                                    modifier = Modifier
                                        .padding(start = offsetStartDp)
                                        .width(textWidthDp)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(TrackTextColor.copy(alpha = 0.9f))
                                        .padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.TextFields,
                                            contentDescription = "Text",
                                            tint = Color.Black,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = textItem.text,
                                            color = Color.Black,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1E202A),
                                modifier = Modifier
                                    .clickable { onAddTextClick() }
                                    .testTag("add_text_pill")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.TextFields,
                                        contentDescription = "Add Text",
                                        tint = TrackTextColor,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "+ Add Text / Caption",
                                        color = CapCutTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Central / Scrubbable Playhead Indicator Line
            val playheadXOffset = (24f + (currentPlayheadMs * pxPerMs) - scrollState.value).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(playheadXOffset, 0) }
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.White)
            ) {
                // Playhead Arrow Header
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .size(10.dp)
                        .background(CapCutCyan, RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

@Composable
private fun TimelineRuler(
    totalDurationMs: Long,
    pxPerMs: Float,
    modifier: Modifier = Modifier
) {
    val totalSeconds = ((totalDurationMs + 4000L) / 1000).toInt()

    Row(modifier = modifier) {
        for (sec in 0..totalSeconds) {
            val secWidthDp = (1000 * pxPerMs).dp
            Column(
                modifier = Modifier.width(secWidthDp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = String.format("%02d:%02d", sec / 60, sec % 60),
                    color = CapCutTextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.width(1.dp).height(5.dp).background(CapCutTextMuted))
                    Box(modifier = Modifier.width(1.dp).height(3.dp).background(CapCutTextMuted.copy(alpha = 0.5f)))
                    Box(modifier = Modifier.width(1.dp).height(3.dp).background(CapCutTextMuted.copy(alpha = 0.5f)))
                    Box(modifier = Modifier.width(1.dp).height(3.dp).background(CapCutTextMuted.copy(alpha = 0.5f)))
                }
            }
        }
    }
}
