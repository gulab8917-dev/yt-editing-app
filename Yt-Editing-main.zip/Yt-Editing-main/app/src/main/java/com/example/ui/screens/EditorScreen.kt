package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SampleMedia
import com.example.data.model.VideoClip
import com.example.ui.components.AdjustModal
import com.example.ui.components.AspectRatioModal
import com.example.ui.components.AudioPickerModal
import com.example.ui.components.CapCutBottomBar
import com.example.ui.components.ExportDialog
import com.example.ui.components.FiltersModal
import com.example.ui.components.SpeedModal
import com.example.ui.components.TextEditorModal
import com.example.ui.components.TimelineView
import com.example.ui.components.TransitionsModal
import com.example.ui.components.VideoPlayerCanvas
import com.example.ui.theme.CapCutBackground
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutDivider
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutSurfaceElevated
import com.example.ui.theme.CapCutTextPrimary
import com.example.ui.theme.CapCutTextSecondary
import com.example.ui.viewmodel.EditorUiState
import com.example.ui.viewmodel.EditorViewModel
import com.example.ui.viewmodel.ToolModalType
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    projectId: String,
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(projectId) {
        viewModel.loadProject(projectId)
    }

    BackHandler {
        if (uiState.activeModal != ToolModalType.NONE) {
            viewModel.closeModal()
        } else {
            viewModel.pause()
            onNavigateBack()
        }
    }

    // Android Photo Picker for appending video clips/photos
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val newClip = VideoClip(
                id = UUID.randomUUID().toString(),
                title = "Imported Media",
                sourceUri = uri.toString(),
                durationMs = 4000L,
                trimEndMs = 4000L
            )
            viewModel.addClip(newClip)
        } else {
            // Append random sample clip from library
            val randomPreset = SampleMedia.sampleClips.random()
            viewModel.addClip(randomPreset.copy(id = UUID.randomUUID().toString()))
        }
    }

    Scaffold(
        topBar = {
            if (!uiState.isFullscreenPreview) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = uiState.projectTitle,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Text(
                                text = "Auto-saving to drafts",
                                color = CapCutCyan,
                                fontSize = 10.sp
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                viewModel.pause()
                                onNavigateBack()
                            },
                            modifier = Modifier.testTag("editor_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                    },
                    actions = {
                        // Resolution Pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CapCutSurfaceElevated,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = uiState.exportSettings.resolution,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        // Export Button
                        Button(
                            onClick = { viewModel.openModal(ToolModalType.EXPORT) },
                            colors = ButtonDefaults.buttonColors(containerColor = CapCutCyan),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .padding(end = 12.dp)
                                .testTag("export_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = "Export",
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Export",
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = CapCutBackground),
                    modifier = Modifier.statusBarsPadding()
                )
            }
        },
        containerColor = CapCutBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // 1. Video Player Canvas
                VideoPlayerCanvas(
                    clip = uiState.activeClipAtPlayhead,
                    aspectRatio = uiState.aspectRatio,
                    currentPlayheadMs = uiState.currentPlayheadMs,
                    totalDurationMs = uiState.totalDurationMs,
                    isPlaying = uiState.isPlaying,
                    activeTexts = uiState.activeTextOverlays,
                    isFullscreen = uiState.isFullscreenPreview,
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onToggleFullscreen = { viewModel.toggleFullscreenPreview() },
                    onAspectRatioClick = { viewModel.openModal(ToolModalType.ASPECT_RATIO) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(if (uiState.isFullscreenPreview) 1f else 0.52f)
                )

                if (!uiState.isFullscreenPreview) {
                    // 2. Timeline Multi-Track Component
                    TimelineView(
                        clips = uiState.clips,
                        selectedClipId = uiState.selectedClipId,
                        audioTracks = uiState.audioTracks,
                        textOverlays = uiState.textOverlays,
                        currentPlayheadMs = uiState.currentPlayheadMs,
                        totalDurationMs = uiState.totalDurationMs,
                        isPlaying = uiState.isPlaying,
                        canUndo = uiState.canUndo,
                        canRedo = uiState.canRedo,
                        onPlayPauseClick = { viewModel.togglePlayPause() },
                        onUndoClick = { viewModel.undo() },
                        onRedoClick = { viewModel.redo() },
                        onSeekTo = { viewModel.seekTo(it) },
                        onSelectClip = { viewModel.selectClip(it) },
                        onTransitionClick = { viewModel.selectTransitionSlot(it) },
                        onAddClipClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        onAddAudioClick = { viewModel.openModal(ToolModalType.AUDIO_PICKER) },
                        onAddTextClick = { viewModel.openModal(ToolModalType.TEXT_EDITOR) },
                        onToggleMute = { viewModel.toggleClipMute(it) },
                        modifier = Modifier.weight(0.48f)
                    )

                    // 3. Bottom Action Toolbar
                    CapCutBottomBar(
                        onSplitClick = { viewModel.splitClipAtPlayhead() },
                        onSpeedClick = { viewModel.openModal(ToolModalType.SPEED) },
                        onDeleteClick = { viewModel.deleteSelectedClip() },
                        onDuplicateClick = { viewModel.duplicateSelectedClip() },
                        onFilterClick = { viewModel.openModal(ToolModalType.FILTER) },
                        onAdjustClick = { viewModel.openModal(ToolModalType.ADJUST) },
                        onAudioClick = { viewModel.openModal(ToolModalType.AUDIO_PICKER) },
                        onTextClick = { viewModel.openModal(ToolModalType.TEXT_EDITOR) },
                        onRatioClick = { viewModel.openModal(ToolModalType.ASPECT_RATIO) },
                        onEffectsClick = { viewModel.openModal(ToolModalType.FILTER) }
                    )
                }
            }

            // Bottom Sheets / Modals
            AnimatedVisibility(
                visible = uiState.activeModal != ToolModalType.NONE && uiState.activeModal != ToolModalType.EXPORT,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it }),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                when (uiState.activeModal) {
                    ToolModalType.SPEED -> {
                        SpeedModal(
                            clip = uiState.selectedClip,
                            onSpeedChange = { speed ->
                                uiState.selectedClipId?.let { viewModel.setClipSpeed(it, speed) }
                            },
                            onConfirm = { viewModel.confirmSpeedChange() },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    ToolModalType.FILTER -> {
                        FiltersModal(
                            currentFilter = uiState.selectedClip?.filter ?: com.example.data.model.FilterType.NORMAL,
                            onSelectFilter = { filter ->
                                uiState.selectedClipId?.let { viewModel.setFilter(it, filter) }
                            },
                            onApplyToAll = { filter ->
                                viewModel.applyFilterToAllClips(filter)
                            },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    ToolModalType.ADJUST -> {
                        AdjustModal(
                            clip = uiState.selectedClip,
                            onAdjustmentsChange = { b, c, s, v ->
                                uiState.selectedClipId?.let {
                                    viewModel.updateAdjustments(it, b, c, s, v)
                                }
                            },
                            onConfirm = { viewModel.confirmAdjustments() },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    ToolModalType.TRANSITION -> {
                        TransitionsModal(
                            onSelectTransition = { type, dur ->
                                viewModel.setTransition(type, dur)
                            },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    ToolModalType.TEXT_EDITOR -> {
                        TextEditorModal(
                            onConfirm = { text, colorHex, bgHex, fontSize, anim ->
                                viewModel.addOrUpdateText(null, text, colorHex, bgHex, fontSize, anim)
                            },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    ToolModalType.AUDIO_PICKER -> {
                        AudioPickerModal(
                            onSelectAudio = { audio ->
                                viewModel.addAudioTrack(audio)
                            },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    ToolModalType.ASPECT_RATIO -> {
                        AspectRatioModal(
                            currentRatio = uiState.aspectRatio,
                            onSelectRatio = { ratio ->
                                viewModel.setAspectRatio(ratio)
                            },
                            onClose = { viewModel.closeModal() }
                        )
                    }
                    else -> Unit
                }
            }

            // Export Dialog
            if (uiState.activeModal == ToolModalType.EXPORT) {
                ExportDialog(
                    exportSettings = uiState.exportSettings,
                    isExporting = uiState.isExporting,
                    exportProgress = uiState.exportProgress,
                    exportPhaseText = uiState.exportPhaseText,
                    exportFinished = uiState.exportFinished,
                    durationMs = uiState.totalDurationMs,
                    onSettingsChange = { viewModel.updateExportSettings(it) },
                    onStartExport = { viewModel.startExport() },
                    onCancelExport = { viewModel.cancelExport() },
                    onDismiss = {
                        viewModel.cancelExport()
                        viewModel.closeModal()
                    }
                )
            }
        }
    }
}
