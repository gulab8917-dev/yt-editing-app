package com.example.data.db

import com.example.data.model.AudioTrackItem
import com.example.data.model.FilterType
import com.example.data.model.SoundType
import com.example.data.model.TextOverlayItem
import com.example.data.model.TransitionType
import com.example.data.model.VideoClip
import org.json.JSONArray
import org.json.JSONObject

object ProjectJsonConverter {

    fun clipsToJson(clips: List<VideoClip>): String {
        val array = JSONArray()
        for (clip in clips) {
            val obj = JSONObject()
            obj.put("id", clip.id)
            obj.put("title", clip.title)
            obj.put("sourceUri", clip.sourceUri)
            obj.put("thumbnailRes", clip.thumbnailRes ?: -1)
            obj.put("dominantColorHex", clip.dominantColorHex)
            obj.put("durationMs", clip.durationMs)
            obj.put("trimStartMs", clip.trimStartMs)
            obj.put("trimEndMs", clip.trimEndMs)
            obj.put("speed", clip.speed.toDouble())
            obj.put("volume", clip.volume.toDouble())
            obj.put("transition", clip.transition.name)
            obj.put("transitionDurationMs", clip.transitionDurationMs)
            obj.put("filter", clip.filter.name)
            obj.put("brightness", clip.brightness.toDouble())
            obj.put("contrast", clip.contrast.toDouble())
            obj.put("saturation", clip.saturation.toDouble())
            obj.put("vignette", clip.vignette.toDouble())
            obj.put("isMuted", clip.isMuted)
            obj.put("rotationAngle", clip.rotationAngle.toDouble())
            array.put(obj)
        }
        return array.toString()
    }

    fun clipsFromJson(json: String): List<VideoClip> {
        val list = mutableListOf<VideoClip>()
        if (json.isBlank()) return list
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val thumb = obj.optInt("thumbnailRes", -1)
                list.add(
                    VideoClip(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        sourceUri = obj.optString("sourceUri", ""),
                        thumbnailRes = if (thumb > 0) thumb else null,
                        dominantColorHex = obj.optString("dominantColorHex", "#1E293B"),
                        durationMs = obj.optLong("durationMs", 4000L),
                        trimStartMs = obj.optLong("trimStartMs", 0L),
                        trimEndMs = obj.optLong("trimEndMs", 4000L),
                        speed = obj.optDouble("speed", 1.0).toFloat(),
                        volume = obj.optDouble("volume", 1.0).toFloat(),
                        transition = TransitionType.fromName(obj.optString("transition", "NONE")),
                        transitionDurationMs = obj.optLong("transitionDurationMs", 600L),
                        filter = FilterType.fromName(obj.optString("filter", "NORMAL")),
                        brightness = obj.optDouble("brightness", 0.0).toFloat(),
                        contrast = obj.optDouble("contrast", 0.0).toFloat(),
                        saturation = obj.optDouble("saturation", 0.0).toFloat(),
                        vignette = obj.optDouble("vignette", 0.0).toFloat(),
                        isMuted = obj.optBoolean("isMuted", false),
                        rotationAngle = obj.optDouble("rotationAngle", 0.0).toFloat()
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun audioToJson(audioList: List<AudioTrackItem>): String {
        val array = JSONArray()
        for (item in audioList) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("title", item.title)
            obj.put("artist", item.artist)
            obj.put("startMs", item.startMs)
            obj.put("durationMs", item.durationMs)
            obj.put("volume", item.volume.toDouble())
            obj.put("soundType", item.soundType.name)
            obj.put("waveformSeed", item.waveformSeed)
            array.put(obj)
        }
        return array.toString()
    }

    fun audioFromJson(json: String): List<AudioTrackItem> {
        val list = mutableListOf<AudioTrackItem>()
        if (json.isBlank()) return list
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    AudioTrackItem(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        artist = obj.optString("artist", "CapCut Audio"),
                        startMs = obj.optLong("startMs", 0L),
                        durationMs = obj.optLong("durationMs", 10000L),
                        volume = obj.optDouble("volume", 0.8).toFloat(),
                        soundType = SoundType.valueOf(obj.optString("soundType", "MUSIC")),
                        waveformSeed = obj.optLong("waveformSeed", 42L)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun textToJson(textList: List<TextOverlayItem>): String {
        val array = JSONArray()
        for (item in textList) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("text", item.text)
            obj.put("startMs", item.startMs)
            obj.put("durationMs", item.durationMs)
            obj.put("textColorHex", item.textColorHex)
            obj.put("backgroundColorHex", item.backgroundColorHex)
            obj.put("fontSizeSp", item.fontSizeSp.toDouble())
            obj.put("xPosRatio", item.xPosRatio.toDouble())
            obj.put("yPosRatio", item.yPosRatio.toDouble())
            obj.put("animation", item.animation)
            array.put(obj)
        }
        return array.toString()
    }

    fun textFromJson(json: String): List<TextOverlayItem> {
        val list = mutableListOf<TextOverlayItem>()
        if (json.isBlank()) return list
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    TextOverlayItem(
                        id = obj.getString("id"),
                        text = obj.getString("text"),
                        startMs = obj.optLong("startMs", 0L),
                        durationMs = obj.optLong("durationMs", 3000L),
                        textColorHex = obj.optString("textColorHex", "#FFFFFF"),
                        backgroundColorHex = obj.optString("backgroundColorHex", "#00000088"),
                        fontSizeSp = obj.optDouble("fontSizeSp", 22.0).toFloat(),
                        xPosRatio = obj.optDouble("xPosRatio", 0.5).toFloat(),
                        yPosRatio = obj.optDouble("yPosRatio", 0.75).toFloat(),
                        animation = obj.optString("animation", "Pop In")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }
}
