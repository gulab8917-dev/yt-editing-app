package com.example.data.model

import com.example.R
import java.util.UUID

object SampleMedia {
    val sampleClips = listOf(
        VideoClip(
            id = "clip_cyber_city",
            title = "Cyber City Neon",
            thumbnailRes = R.drawable.template_velocity_1790502966219,
            dominantColorHex = "#0F172A",
            durationMs = 5000L,
            trimStartMs = 0L,
            trimEndMs = 5000L,
            filter = FilterType.CYBER_NEON
        ),
        VideoClip(
            id = "clip_cinematic_road",
            title = "Golden Hour Highway",
            thumbnailRes = R.drawable.template_cinematic_1790502980073,
            dominantColorHex = "#451A03",
            durationMs = 4500L,
            trimStartMs = 0L,
            trimEndMs = 4500L,
            filter = FilterType.SUNSET_WARM,
            transition = TransitionType.ZOOM_IN
        ),
        VideoClip(
            id = "clip_retro_portrait",
            title = "Retro 90s Vibes",
            thumbnailRes = R.drawable.template_aesthetic_1790502995311,
            dominantColorHex = "#312E81",
            durationMs = 4000L,
            trimStartMs = 0L,
            trimEndMs = 4000L,
            filter = FilterType.RETRO_VHS,
            transition = TransitionType.DISSOLVE
        ),
        VideoClip(
            id = "clip_ocean_sunset",
            title = "Pacific Waves Sunset",
            thumbnailRes = R.drawable.template_cinematic_1790502980073,
            dominantColorHex = "#1E3A8A",
            durationMs = 3800L,
            trimStartMs = 0L,
            trimEndMs = 3800L,
            filter = FilterType.TEAL_ORANGE,
            transition = TransitionType.WHIP_PAN
        )
    )

    val sampleAudioLibrary = listOf(
        AudioTrackItem(
            id = "audio_drift_phonk",
            title = "Tokyo Drift Phonk (Slowed + Reverb)",
            artist = "ByteVibes BeatLab",
            durationMs = 15000L,
            volume = 0.85f,
            soundType = SoundType.MUSIC,
            waveformSeed = 101L
        ),
        AudioTrackItem(
            id = "audio_lofi_aesthetic",
            title = "Midnight Coffee Lo-Fi",
            artist = "ChillHop Sessions",
            durationMs = 18000L,
            volume = 0.7f,
            soundType = SoundType.MUSIC,
            waveformSeed = 202L
        ),
        AudioTrackItem(
            id = "audio_cinematic_epic",
            title = "Horizons Cinematic Build",
            artist = "Epic Soundworks",
            durationMs = 16000L,
            volume = 0.9f,
            soundType = SoundType.MUSIC,
            waveformSeed = 303L
        ),
        AudioTrackItem(
            id = "sfx_whoosh_trans",
            title = "Fast Cinematic Whoosh",
            artist = "Sound FX",
            durationMs = 1200L,
            volume = 1.0f,
            soundType = SoundType.SFX,
            waveformSeed = 404L
        ),
        AudioTrackItem(
            id = "sfx_camera_shutter",
            title = "Camera Shutter & Flash",
            artist = "Sound FX",
            durationMs = 800L,
            volume = 1.0f,
            soundType = SoundType.SFX,
            waveformSeed = 505L
        ),
        AudioTrackItem(
            id = "sfx_bass_drop",
            title = "Sub Bass 808 Impact",
            artist = "Sound FX",
            durationMs = 2000L,
            volume = 0.95f,
            soundType = SoundType.SFX,
            waveformSeed = 606L
        )
    )

    fun createDefaultProjectClips(): List<VideoClip> {
        return sampleClips.map { it.copy(id = UUID.randomUUID().toString()) }
    }
}
