package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CapCut signature theme colors
val CapCutCyan = Color(0xFF00E5FF)
val CapCutCyanLight = Color(0xFF80F2FF)
val CapCutCyanDark = Color(0xFF00B4D8)

val CapCutBackground = Color(0xFF0E1015)
val CapCutSurface = Color(0xFF161922)
val CapCutSurfaceVariant = Color(0xFF1F2330)
val CapCutSurfaceElevated = Color(0xFF282E3E)

val CapCutDivider = Color(0xFF2A2F3D)
val CapCutTextPrimary = Color(0xFFF8F9FA)
val CapCutTextSecondary = Color(0xFFA0A5B5)
val CapCutTextMuted = Color(0xFF6B7280)

val TrackVideoColor = Color(0xFF1E293B)
val TrackAudioColor = Color(0xFF6366F1)
val TrackTextColor = Color(0xFFF59E0B)
val TrackEffectColor = Color(0xFFEC4899)
val PlayheadColor = Color(0xFF00F0FF)
val ActiveSelectionColor = Color(0xFFFFFFFF)

