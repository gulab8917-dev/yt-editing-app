package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CapCutBackground
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutDivider
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutSurfaceElevated
import com.example.ui.theme.CapCutTextPrimary
import com.example.ui.theme.CapCutTextSecondary

data class TutorialItem(
    val id: String,
    val title: String,
    val level: String,
    val duration: String,
    val icon: ImageVector,
    val accentColor: Color,
    val steps: List<String>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TutorialsScreen() {
    val tutorials = listOf(
        TutorialItem(
            id = "tut_velocity",
            title = "How to Create Smooth Velocity Beat Sync",
            level = "Pro Masterclass",
            duration = "4 min read",
            icon = Icons.Default.Speed,
            accentColor = Color(0xFF00E5FF),
            steps = listOf(
                "1. Place music track on timeline and locate the heavy bass drops.",
                "2. Tap 'Split' right on each bass drop marker.",
                "3. Adjust first half of clip to 0.4x speed (Slow-mo) and next to 2.5x speed (Fast).",
                "4. Add 'Zoom In' transition with 0.4s duration for seamless momentum!"
            )
        ),
        TutorialItem(
            id = "tut_color_grading",
            title = "Hollywood Teal & Orange Film Color Grade",
            level = "Intermediate",
            duration = "3 min read",
            icon = Icons.Default.ColorLens,
            accentColor = Color(0xFFFB923C),
            steps = listOf(
                "1. Select your outdoor or golden hour video clip in timeline.",
                "2. Open 'Filters' and apply 'Teal & Orange' preset.",
                "3. Go to 'Adjust' > Set Brightness to +8, Contrast to +18, and Saturation to +15.",
                "4. Add a subtle Vignette of 25% to focus on the center subject."
            )
        ),
        TutorialItem(
            id = "tut_transitions",
            title = "Seamless Whip Pan & Glitch Cuts",
            level = "Beginner",
            duration = "2 min read",
            icon = Icons.Default.Transform,
            accentColor = Color(0xFFEC4899),
            steps = listOf(
                "1. Align two consecutive motion clips on the main track.",
                "2. Tap the square transition button (|><|) between the two clips.",
                "3. Select 'Whip Pan' or 'Glitch Cut' and set duration to 0.5s.",
                "4. Add a 'Fast Cinematic Whoosh' sound effect right at the cut point."
            )
        ),
        TutorialItem(
            id = "tut_subtitles",
            title = "Trendy Animated TikTok Captions",
            level = "All Levels",
            duration = "3 min read",
            icon = Icons.Default.Videocam,
            accentColor = Color(0xFF10B981),
            steps = listOf(
                "1. Tap 'Text' in bottom toolbar and choose 'Add Text'.",
                "2. Select modern high-contrast color (Yellow or Electric Cyan).",
                "3. Choose 'Pop In' or 'Typewriter' animation style.",
                "4. Position caption in lower third of canvas for mobile viewports."
            )
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "CapCut Creator Masterclass",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CapCutBackground),
                modifier = Modifier.statusBarsPadding()
            )
        },
        containerColor = CapCutBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            item {
                // Hero Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF1F1D36), Color(0xFF382956), Color(0xFF0F172A))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = CapCutCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("LEVEL UP YOUR EDITS", color = CapCutCyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "CapCut Video Editing Guides",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Learn how top creators craft viral TikToks, Reels, and YouTube Shorts using mobile editing tools.",
                            color = CapCutTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            items(tutorials, key = { it.id }) { tut ->
                TutorialCard(tut = tut)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun TutorialCard(tut: TutorialItem) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CapCutSurface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(tut.accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tut.icon,
                            contentDescription = null,
                            tint = tut.accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = tut.title,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${tut.level} • ${tut.duration}",
                            color = CapCutTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (expanded) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CapCutSurfaceElevated)
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        tut.steps.forEach { step ->
                            Text(
                                text = step,
                                color = CapCutTextPrimary,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
