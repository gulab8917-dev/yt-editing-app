package com.example.data.model

enum class AspectRatio(val label: String, val ratioWidth: Float, val ratioHeight: Float, val tag: String) {
    RATIO_9_16("9:16", 9f, 16f, "TikTok / Reels / Shorts"),
    RATIO_16_9("16:9", 16f, 9f, "YouTube / Landscape"),
    RATIO_1_1("1:1", 1f, 1f, "Instagram Feed"),
    RATIO_4_5("4:5", 4f, 5f, "Portrait Post"),
    RATIO_21_9("21:9", 21f, 9f, "Cinematic Ultra");

    companion object {
        fun fromLabel(label: String): AspectRatio =
            values().find { it.label == label } ?: RATIO_9_16
    }
}

enum class FilterType(val displayName: String, val description: String) {
    NORMAL("Normal", "Original clean colors"),
    CINEMATIC("Cinematic", "High contrast movie look"),
    TEAL_ORANGE("Teal & Orange", "Hollywood blockbuster grade"),
    CYBER_NEON("Cyberpunk", "Vivid neon blues and magentas"),
    RETRO_VHS("Retro 90s", "Warm vintage film grain"),
    MONO_BW("Monochrome", "Dramatic black and white"),
    SUNSET_WARM("Golden Hour", "Soft warm sunlight tones"),
    EMERALD_COOL("Emerald", "Lush cold emerald greens");

    companion object {
        fun fromName(name: String): FilterType =
            values().find { it.name == name } ?: NORMAL
    }
}

enum class TransitionType(val displayName: String, val iconName: String) {
    NONE("None", "none"),
    DISSOLVE("Dissolve", "dissolve"),
    FADE_BLACK("Fade Black", "fade"),
    ZOOM_IN("Zoom In", "zoom"),
    WHIP_PAN("Whip Pan", "whip"),
    GLITCH("Glitch Cut", "glitch"),
    SLIDE_LEFT("Slide", "slide");

    companion object {
        fun fromName(name: String): TransitionType =
            values().find { it.name == name } ?: NONE
    }
}

enum class EffectType(val displayName: String, val category: String) {
    EDGE_GLOW("Edge Glow", "Light"),
    LENS_BLUR("Lens Blur", "Lens"),
    CAMERA_SHAKE("Camera Shake", "Action"),
    RGB_SPLIT("RGB Split", "Glitch"),
    FILM_SCRATCH("Film Dust", "Retro"),
    BEAT_FLASH("Beat Flash", "Rhythm");

    companion object {
        fun fromName(name: String): EffectType =
            values().find { it.name == name } ?: EDGE_GLOW
    }
}

enum class SoundType {
    MUSIC, SFX, VOICEOVER
}

data class VideoClip(
    val id: String,
    val title: String,
    val sourceUri: String = "",
    val thumbnailRes: Int? = null,
    val dominantColorHex: String = "#1E293B",
    val durationMs: Long = 4000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 4000L,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val transition: TransitionType = TransitionType.NONE,
    val transitionDurationMs: Long = 600L,
    val filter: FilterType = FilterType.NORMAL,
    val brightness: Float = 0f, // -100 to 100
    val contrast: Float = 0f,   // -100 to 100
    val saturation: Float = 0f, // -100 to 100
    val vignette: Float = 0f,   // 0 to 100
    val isMuted: Boolean = false,
    val rotationAngle: Float = 0f
) {
    val effectiveDurationMs: Long
        get() = ((trimEndMs - trimStartMs) / speed).toLong().coerceAtLeast(200L)
}

data class AudioTrackItem(
    val id: String,
    val title: String,
    val artist: String = "CapCut Audio",
    val startMs: Long = 0L,
    val durationMs: Long = 12000L,
    val volume: Float = 0.8f,
    val soundType: SoundType = SoundType.MUSIC,
    val waveformSeed: Long = 42L
)

data class TextOverlayItem(
    val id: String,
    val text: String,
    val startMs: Long = 500L,
    val durationMs: Long = 3000L,
    val textColorHex: String = "#FFFFFF",
    val backgroundColorHex: String = "#00000088",
    val fontSizeSp: Float = 22f,
    val xPosRatio: Float = 0.5f, // center horizontally
    val yPosRatio: Float = 0.75f, // lower third like TikTok captions
    val animation: String = "Pop In"
)

data class VideoEffectItem(
    val id: String,
    val effectType: EffectType,
    val startMs: Long = 0L,
    val durationMs: Long = 2500L,
    val intensity: Float = 0.8f
)

data class ExportSettings(
    val resolution: String = "1080P",
    val fps: Int = 60,
    val bitrateMode: String = "Higher",
    val format: String = "MP4"
)
