package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatio
import com.example.data.model.AudioTrackItem
import com.example.data.model.FilterType
import com.example.data.model.SampleMedia
import com.example.data.model.TransitionType
import com.example.data.model.VideoClip
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutDivider
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutSurfaceElevated
import com.example.ui.theme.CapCutSurfaceVariant
import com.example.ui.theme.CapCutTextPrimary
import com.example.ui.theme.CapCutTextSecondary

// Modal Container
@Composable
fun ModalContainer(
    title: String,
    onClose: () -> Unit,
    onConfirm: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CapCutSurface)
            .border(1.dp, CapCutDivider, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = CapCutTextSecondary
                )
            }
            Text(
                text = title,
                color = CapCutTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            if (onConfirm != null) {
                IconButton(onClick = onConfirm, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Confirm",
                        tint = CapCutCyan
                    )
                }
            } else {
                Spacer(modifier = Modifier.size(36.dp))
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        content()
    }
}

// 1. Speed Adjustment Modal
@Composable
fun SpeedModal(
    clip: VideoClip?,
    onSpeedChange: (Float) -> Unit,
    onConfirm: () -> Unit,
    onClose: () -> Unit
) {
    var speed by remember(clip?.id) { mutableFloatStateOf(clip?.speed ?: 1.0f) }

    ModalContainer(
        title = "Speed / Slow Motion",
        onClose = onClose,
        onConfirm = {
            onSpeedChange(speed)
            onConfirm()
        }
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = String.format("%.2fx", speed),
                color = CapCutCyan,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Presets
            val presets = listOf(0.2f, 0.5f, 1.0f, 1.5f, 2.0f, 4.0f, 8.0f)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                presets.forEach { preset ->
                    val isSelected = (speed - preset).let { if (it < 0) -it else it } < 0.05f
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) CapCutCyan else CapCutSurfaceElevated,
                        modifier = Modifier.clickable {
                            speed = preset
                            onSpeedChange(preset)
                        }
                    ) {
                        Text(
                            text = "${preset}x",
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Slider(
                value = speed,
                onValueChange = {
                    speed = (it * 10).toInt() / 10f
                    onSpeedChange(speed)
                },
                valueRange = 0.1f..10.0f,
                colors = SliderDefaults.colors(
                    thumbColor = CapCutCyan,
                    activeTrackColor = CapCutCyan,
                    inactiveTrackColor = CapCutDivider
                ),
                modifier = Modifier.testTag("speed_slider")
            )
        }
    }
}

// 2. Filters Modal
@Composable
fun FiltersModal(
    currentFilter: FilterType,
    onSelectFilter: (FilterType) -> Unit,
    onApplyToAll: (FilterType) -> Unit,
    onClose: () -> Unit
) {
    ModalContainer(title = "Video Filters & Grading", onClose = onClose) {
        Column {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(FilterType.values()) { filter ->
                    val isSelected = filter == currentFilter
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(72.dp)
                            .clickable { onSelectFilter(filter) }
                            .testTag("filter_${filter.name}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    when (filter) {
                                        FilterType.CYBER_NEON -> Color(0xFF00E5FF)
                                        FilterType.TEAL_ORANGE -> Color(0xFFFB923C)
                                        FilterType.RETRO_VHS -> Color(0xFFCA8A04)
                                        FilterType.MONO_BW -> Color(0xFF6B7280)
                                        FilterType.SUNSET_WARM -> Color(0xFFE11D48)
                                        FilterType.EMERALD_COOL -> Color(0xFF059669)
                                        FilterType.CINEMATIC -> Color(0xFF3B82F6)
                                        FilterType.NORMAL -> Color(0xFF374151)
                                    }
                                )
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = filter.displayName.take(3),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = filter.displayName,
                            color = if (isSelected) CapCutCyan else CapCutTextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { onApplyToAll(currentFilter) },
                colors = ButtonDefaults.buttonColors(containerColor = CapCutSurfaceElevated),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Apply to All Clips", color = CapCutCyan)
            }
        }
    }
}

// 3. Adjustments Modal
@Composable
fun AdjustModal(
    clip: VideoClip?,
    onAdjustmentsChange: (brightness: Float, contrast: Float, saturation: Float, vignette: Float) -> Unit,
    onConfirm: () -> Unit,
    onClose: () -> Unit
) {
    var brightness by remember(clip?.id) { mutableFloatStateOf(clip?.brightness ?: 0f) }
    var contrast by remember(clip?.id) { mutableFloatStateOf(clip?.contrast ?: 0f) }
    var saturation by remember(clip?.id) { mutableFloatStateOf(clip?.saturation ?: 0f) }
    var vignette by remember(clip?.id) { mutableFloatStateOf(clip?.vignette ?: 0f) }

    ModalContainer(
        title = "Color Adjustment",
        onClose = onClose,
        onConfirm = {
            onAdjustmentsChange(brightness, contrast, saturation, vignette)
            onConfirm()
        }
    ) {
        Column {
            AdjustmentSliderItem(
                label = "Brightness",
                value = brightness,
                range = -100f..100f,
                onValueChange = {
                    brightness = it
                    onAdjustmentsChange(brightness, contrast, saturation, vignette)
                }
            )
            AdjustmentSliderItem(
                label = "Contrast",
                value = contrast,
                range = -100f..100f,
                onValueChange = {
                    contrast = it
                    onAdjustmentsChange(brightness, contrast, saturation, vignette)
                }
            )
            AdjustmentSliderItem(
                label = "Saturation",
                value = saturation,
                range = -100f..100f,
                onValueChange = {
                    saturation = it
                    onAdjustmentsChange(brightness, contrast, saturation, vignette)
                }
            )
            AdjustmentSliderItem(
                label = "Vignette",
                value = vignette,
                range = 0f..100f,
                onValueChange = {
                    vignette = it
                    onAdjustmentsChange(brightness, contrast, saturation, vignette)
                }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = {
                    brightness = 0f
                    contrast = 0f
                    saturation = 0f
                    vignette = 0f
                    onAdjustmentsChange(0f, 0f, 0f, 0f)
                }) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset",
                        tint = CapCutTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset All", color = CapCutTextSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun AdjustmentSliderItem(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, color = CapCutTextPrimary, fontSize = 13.sp)
            Text(text = "${value.toInt()}", color = CapCutCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = CapCutCyan,
                activeTrackColor = CapCutCyan,
                inactiveTrackColor = CapCutDivider
            )
        )
    }
}

// 4. Transitions Modal
@Composable
fun TransitionsModal(
    onSelectTransition: (TransitionType, Long) -> Unit,
    onClose: () -> Unit
) {
    var selectedType by remember { mutableStateOf(TransitionType.DISSOLVE) }
    var durationMs by remember { mutableFloatStateOf(600f) }

    ModalContainer(
        title = "Transition Effects",
        onClose = onClose,
        onConfirm = { onSelectTransition(selectedType, durationMs.toLong()) }
    ) {
        Column {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(TransitionType.values()) { trans ->
                    val isSelected = trans == selectedType
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(70.dp)
                            .clickable { selectedType = trans }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) CapCutCyan else CapCutSurfaceElevated)
                                .border(1.dp, if (isSelected) Color.White else CapCutDivider, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = trans.displayName.take(2).uppercase(),
                                color = if (isSelected) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = trans.displayName,
                            color = if (isSelected) CapCutCyan else CapCutTextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Duration", color = CapCutTextPrimary, fontSize = 13.sp)
                Text(String.format("%.1fs", durationMs / 1000f), color = CapCutCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = durationMs,
                onValueChange = { durationMs = it },
                valueRange = 200f..2000f,
                colors = SliderDefaults.colors(thumbColor = CapCutCyan, activeTrackColor = CapCutCyan)
            )
        }
    }
}

// 5. Text Caption Editor Modal
@Composable
fun TextEditorModal(
    initialText: String = "",
    onConfirm: (text: String, colorHex: String, bgHex: String, fontSizeSp: Float, animation: String) -> Unit,
    onClose: () -> Unit
) {
    var text by remember { mutableStateOf(initialText) }
    var selectedColorHex by remember { mutableStateOf("#FFFFFF") }
    var selectedAnimation by remember { mutableStateOf("Pop In") }

    val colors = listOf("#FFFFFF", "#00F0FF", "#FDE047", "#FF007A", "#22C55E", "#000000")
    val animations = listOf("Pop In", "Fade In", "Typewriter", "Glitch", "Bounce")

    ModalContainer(
        title = "Add Text / Subtitles",
        onClose = onClose,
        onConfirm = {
            if (text.isNotBlank()) {
                onConfirm(text, selectedColorHex, "#00000088", 22f, selectedAnimation)
            }
        }
    ) {
        Column {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Enter your text caption...", color = CapCutTextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CapCutCyan,
                    unfocusedBorderColor = CapCutDivider,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("text_input_field")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("Text Color", color = CapCutTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                colors.forEach { hex ->
                    val isSelected = hex == selectedColorHex
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                try {
                                    Color(android.graphics.Color.parseColor(hex))
                                } catch (e: Exception) {
                                    Color.White
                                }
                            )
                            .border(2.dp, if (isSelected) CapCutCyan else Color.Transparent, CircleShape)
                            .clickable { selectedColorHex = hex }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("Animation Style", color = CapCutTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(animations) { anim ->
                    val isSelected = anim == selectedAnimation
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) CapCutCyan else CapCutSurfaceElevated,
                        modifier = Modifier.clickable { selectedAnimation = anim }
                    ) {
                        Text(
                            text = anim,
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

// 6. Audio / Sound FX Picker Modal
@Composable
fun AudioPickerModal(
    onSelectAudio: (AudioTrackItem) -> Unit,
    onClose: () -> Unit
) {
    ModalContainer(title = "Music & Sound Effects", onClose = onClose) {
        Column {
            Text("Trending CapCut Tracks", color = CapCutTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))

            SampleMedia.sampleAudioLibrary.forEach { audio ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CapCutSurfaceElevated)
                        .clickable { onSelectAudio(audio) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF6366F1).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Audio",
                                tint = Color(0xFF818CF8),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(audio.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(audio.artist, color = CapCutTextSecondary, fontSize = 11.sp)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CapCutCyan
                    ) {
                        Text(
                            text = "Use",
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

// 7. Aspect Ratio Modal
@Composable
fun AspectRatioModal(
    currentRatio: AspectRatio,
    onSelectRatio: (AspectRatio) -> Unit,
    onClose: () -> Unit
) {
    ModalContainer(title = "Aspect Ratio Canvas", onClose = onClose) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AspectRatio.values().forEach { ratio ->
                val isSelected = ratio == currentRatio
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CapCutSurfaceElevated else Color.Transparent)
                        .border(1.dp, if (isSelected) CapCutCyan else CapCutDivider, RoundedCornerShape(8.dp))
                        .clickable { onSelectRatio(ratio) }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(ratio.label, color = if (isSelected) CapCutCyan else Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(ratio.tag, color = CapCutTextSecondary, fontSize = 11.sp)
                    }
                    if (isSelected) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = "Selected", tint = CapCutCyan)
                    }
                }
            }
        }
    }
}
