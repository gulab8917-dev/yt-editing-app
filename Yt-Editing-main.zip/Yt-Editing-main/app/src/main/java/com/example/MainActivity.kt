package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MeScreen
import com.example.ui.screens.TemplatesScreen
import com.example.ui.screens.TutorialsScreen
import com.example.ui.theme.CapCutBackground
import com.example.ui.theme.CapCutCyan
import com.example.ui.theme.CapCutDivider
import com.example.ui.theme.CapCutSurface
import com.example.ui.theme.CapCutTextSecondary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.EditorViewModel
import com.example.ui.viewmodel.ProjectsViewModel

enum class MainTab(val label: String, val icon: ImageVector, val tag: String) {
    EDIT("Edit", Icons.Default.ContentCut, "tab_edit"),
    TEMPLATES("Templates", Icons.Default.TrendingUp, "tab_templates"),
    TUTORIALS("Tutorials", Icons.Default.MenuBook, "tab_tutorials"),
    ME("Me", Icons.Default.Person, "tab_me")
}

class MainActivity : ComponentActivity() {

    private val projectsViewModel: ProjectsViewModel by viewModels()
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                CapCutApp(
                    projectsViewModel = projectsViewModel,
                    editorViewModel = editorViewModel
                )
            }
        }
    }
}

@Composable
fun CapCutApp(
    projectsViewModel: ProjectsViewModel,
    editorViewModel: EditorViewModel
) {
    var activeProjectId by remember { mutableStateOf<String?>(null) }
    var currentTab by remember { mutableStateOf(MainTab.EDIT) }

    if (activeProjectId != null) {
        // Fullscreen Editor Studio
        EditorScreen(
            projectId = activeProjectId!!,
            viewModel = editorViewModel,
            onNavigateBack = {
                activeProjectId = null
            }
        )
    } else {
        // Main Dashboard with Bottom Navigation Bar
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = CapCutSurface,
                    tonalElevation = 0.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.height(64.dp)
                ) {
                    MainTab.values().forEach { tab ->
                        val isSelected = currentTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.label,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = tab.label,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                unselectedIconColor = CapCutTextSecondary,
                                selectedTextColor = CapCutCyan,
                                unselectedTextColor = CapCutTextSecondary,
                                indicatorColor = CapCutCyan
                            ),
                            modifier = Modifier.testTag(tab.tag)
                        )
                    }
                }
            },
            containerColor = CapCutBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "tab_transition"
                ) { tab ->
                    when (tab) {
                        MainTab.EDIT -> {
                            HomeScreen(
                                viewModel = projectsViewModel,
                                onOpenProject = { activeProjectId = it }
                            )
                        }
                        MainTab.TEMPLATES -> {
                            TemplatesScreen(
                                viewModel = projectsViewModel,
                                onOpenProject = { activeProjectId = it }
                            )
                        }
                        MainTab.TUTORIALS -> {
                            TutorialsScreen()
                        }
                        MainTab.ME -> {
                            MeScreen(viewModel = projectsViewModel)
                        }
                    }
                }
            }
        }
    }
}
