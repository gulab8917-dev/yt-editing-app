package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.db.AppDatabase
import com.example.data.model.AspectRatio
import com.example.data.model.FilterType
import com.example.data.model.ProjectEntity
import com.example.data.model.SampleMedia
import com.example.data.model.TemplateItem
import com.example.data.model.TransitionType
import com.example.data.model.VideoClip
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ProjectsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository

    val projects: StateFlow<List<ProjectEntity>>

    private val _isSeeded = MutableStateFlow(false)

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ProjectRepository(db.projectDao())
        projects = repository.allProjects.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Seed initial project if database is fresh
        viewModelScope.launch {
            repository.allProjects.collect { list ->
                if (!_isSeeded.value && list.isEmpty()) {
                    _isSeeded.value = true
                    seedInitialProjects()
                }
            }
        }
    }

    private suspend fun seedInitialProjects() {
        val dateFormat = SimpleDateFormat("MM-dd", Locale.getDefault())
        val today = dateFormat.format(Date())

        // Seed 1: Cyberpunk Reel
        val clipList1 = listOf(
            SampleMedia.sampleClips[0].copy(id = UUID.randomUUID().toString()),
            SampleMedia.sampleClips[1].copy(id = UUID.randomUUID().toString())
        )
        val totalMs1 = clipList1.sumOf { it.effectiveDurationMs }
        repository.saveProject(
            id = UUID.randomUUID().toString(),
            title = "Tokyo Night Drive $today",
            durationMs = totalMs1,
            aspectRatio = AspectRatio.RATIO_9_16.label,
            coverResId = R.drawable.template_velocity_1790502966219,
            coverUri = null,
            clips = clipList1,
            audioTracks = listOf(SampleMedia.sampleAudioLibrary[0]),
            textOverlays = emptyList()
        )

        // Seed 2: Aesthetic Vlog
        val clipList2 = listOf(
            SampleMedia.sampleClips[2].copy(id = UUID.randomUUID().toString()),
            SampleMedia.sampleClips[3].copy(id = UUID.randomUUID().toString())
        )
        val totalMs2 = clipList2.sumOf { it.effectiveDurationMs }
        repository.saveProject(
            id = UUID.randomUUID().toString(),
            title = "Weekend 35mm Vlog",
            durationMs = totalMs2,
            aspectRatio = AspectRatio.RATIO_9_16.label,
            coverResId = R.drawable.template_aesthetic_1790502995311,
            coverUri = null,
            clips = clipList2,
            audioTracks = listOf(SampleMedia.sampleAudioLibrary[1]),
            textOverlays = emptyList()
        )
    }

    fun createNewProject(
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val dateFormat = SimpleDateFormat("MM/dd HH:mm", Locale.getDefault())
            val title = "Draft ${dateFormat.format(Date())}"
            val initialClips = SampleMedia.createDefaultProjectClips()
            val duration = initialClips.sumOf { it.effectiveDurationMs }
            val initialAudio = listOf(SampleMedia.sampleAudioLibrary[0])

            repository.saveProject(
                id = id,
                title = title,
                durationMs = duration,
                aspectRatio = AspectRatio.RATIO_9_16.label,
                coverResId = initialClips.firstOrNull()?.thumbnailRes ?: R.drawable.template_velocity_1790502966219,
                coverUri = null,
                clips = initialClips,
                audioTracks = initialAudio,
                textOverlays = emptyList()
            )
            onCreated(id)
        }
    }

    fun createProjectFromTemplate(template: TemplateItem, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val clips = template.generateClips()
            val audio = listOf(template.generateAudio())
            val texts = template.generateTexts()
            val duration = clips.sumOf { it.effectiveDurationMs }

            repository.saveProject(
                id = id,
                title = "${template.title} Draft",
                durationMs = duration,
                aspectRatio = template.aspectRatio.label,
                coverResId = template.coverResId,
                coverUri = null,
                clips = clips,
                audioTracks = audio,
                textOverlays = texts
            )
            onCreated(id)
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }

    fun duplicateProject(id: String, currentTitle: String) {
        viewModelScope.launch {
            val newId = UUID.randomUUID().toString()
            repository.duplicateProject(id, newId, "$currentTitle (Copy)")
        }
    }
}
