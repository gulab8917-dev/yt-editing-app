package com.example.data.repository

import com.example.data.db.ProjectDao
import com.example.data.db.ProjectJsonConverter
import com.example.data.model.AudioTrackItem
import com.example.data.model.ProjectEntity
import com.example.data.model.TextOverlayItem
import com.example.data.model.VideoClip
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    suspend fun getProject(id: String): ProjectEntity? = projectDao.getProjectById(id)

    suspend fun saveProject(
        id: String,
        title: String,
        durationMs: Long,
        aspectRatio: String,
        coverResId: Int?,
        coverUri: String?,
        clips: List<VideoClip>,
        audioTracks: List<AudioTrackItem>,
        textOverlays: List<TextOverlayItem>,
        resolution: String = "1080P",
        fps: Int = 60
    ) {
        val existing = projectDao.getProjectById(id)
        val createdAt = existing?.createdAt ?: System.currentTimeMillis()
        val entity = ProjectEntity(
            id = id,
            title = title,
            createdAt = createdAt,
            updatedAt = System.currentTimeMillis(),
            durationMs = durationMs,
            aspectRatio = aspectRatio,
            coverResId = coverResId,
            coverUri = coverUri,
            clipsJson = ProjectJsonConverter.clipsToJson(clips),
            audioJson = ProjectJsonConverter.audioToJson(audioTracks),
            textJson = ProjectJsonConverter.textToJson(textOverlays),
            resolution = resolution,
            fps = fps
        )
        projectDao.insertProject(entity)
    }

    suspend fun deleteProject(id: String) {
        projectDao.deleteProjectById(id)
    }

    suspend fun duplicateProject(originalId: String, newId: String, newTitle: String) {
        val original = projectDao.getProjectById(originalId) ?: return
        val duplicate = original.copy(
            id = newId,
            title = newTitle,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        projectDao.insertProject(duplicate)
    }
}
